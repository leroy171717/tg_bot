from aiogram.types import BotCommand

private = [
    BotCommand(command='menu', description='Посмотреть меню'),
    BotCommand(command='about', description='О боте:'),
    BotCommand(command='info', description='Информация'),
    #BotCommand(command='menu', description='Посмотреть меню')
]